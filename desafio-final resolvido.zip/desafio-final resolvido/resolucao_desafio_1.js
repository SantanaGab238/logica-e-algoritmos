
const prompt = require('prompt-sync')();


const nomes = [];
const idades = [];

console.log("--- Cadastro de Pessoas ---");
for (let i = 0; i < 3; i++) {
    console.log(`\nDigite os dados da ${i + 1}ª pessoa:`);
    
    let nome = prompt("Nome: ");
    let idade = parseInt(prompt("Idade: "), 10);
    
    nomes.push(nome);
    idades.push(idade);
}

let visualizar;
while (true) {
    visualizar = prompt("\nDeseja visualizar os dados? (sim/não): ").toLowerCase().trim();
    
   
    if (visualizar === "sim" || visualizar === "não" || visualizar === "nao") {
        break; 
    } else {
        console.log("Resposta inválida! Tente novamente!");
    }
}

if (visualizar === "sim") {
    console.log("\n=== Exibindo Dados Cadastrados ===");
    
    for (let i = 0; i < 3; i++) {
        let classificacao = "";
        
        if (idades[i] < 18) {
            classificacao = "Menor de idade";
        } else if (idades[i] >= 18 && idades[i] <= 59) { 
            classificacao = "Maior de idade";
        } else {
            classificacao = "Idoso(a)";
        }
        
        console.log(`\n--- Pessoa ${i + 1} ---`);
        console.log(`Nome:          ${nomes[i]}`);
        console.log(`Idade:         ${idades[i]} anos`);
        console.log(`Classificação: ${classificacao}`);
    }
} else {
    console.log("\nPrograma finalizado com sucesso!");
}